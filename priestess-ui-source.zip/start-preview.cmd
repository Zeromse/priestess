@echo off
setlocal
cd /d "%~dp0"
if not defined PORT set "PORT=4177"

where node.exe >nul 2>nul
if not errorlevel 1 (
  node.exe server.cjs --open
  goto finished
)

set "PREVIEW_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
if exist "%PREVIEW_NODE%" (
  "%PREVIEW_NODE%" server.cjs --open
  goto finished
)

echo Node.js was not found. You can also open index.html directly.
echo Install Node.js or use a computer with the Codex bundled runtime.

:finished
pause
endlocal
