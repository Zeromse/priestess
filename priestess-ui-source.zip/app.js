/* 普瑞赛斯影像档案：纯原生 JavaScript，可在 file:// 下离线运行。 */
(() => {
  'use strict';
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => Array.from(scope.querySelectorAll(selector));
  const root = document.documentElement;
  const motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');
  let reducedMotion = motionPreference.matches;
  let motionOverride = false;
  const motionButton = $('#motion-toggle');
  function updateMotion() {
    root.classList.toggle('reduce-motion', reducedMotion);
    motionButton.setAttribute('aria-pressed', String(!reducedMotion));
    motionButton.textContent = `动效：${reducedMotion ? '关闭' : '开启'}`;
  }
  updateMotion();
  motionButton.addEventListener('click', () => { motionOverride = true; reducedMotion = !reducedMotion; updateMotion(); });
  motionPreference.addEventListener('change', event => { if (!motionOverride) { reducedMotion = event.matches; updateMotion(); } });

  // 原生对话框提供焦点约束、Escape 关闭以及背景 inert 语义。
  const frameDialog = $('#frame-dialog');
  const videoDialog = $('#video-dialog');
  const video = $('#reference-video');
  const scrubber = $('#video-scrub');
  const videoToggle = $('#video-toggle');
  let dialogOrigin = null;
  function syncScrollLock() { document.body.classList.toggle('dialog-open', $$('dialog[open]').length > 0); }
  function openDialog(dialog, origin) {
    dialogOrigin = origin || document.activeElement;
    if (!dialog.open) dialog.showModal();
    syncScrollLock();
  }
  $$('dialog').forEach(dialog => {
    dialog.addEventListener('click', event => {
      if (event.target !== dialog) return;
      const bounds = dialog.getBoundingClientRect();
      if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) dialog.close();
    });
    dialog.addEventListener('close', () => {
      if (dialog === videoDialog) video.pause();
      syncScrollLock();
      if (!$$('dialog[open]').length && dialogOrigin?.isConnected) dialogOrigin.focus({ preventScroll: true });
    });
  });
  $$('[data-close-dialog]').forEach(button => button.addEventListener('click', () => button.closest('dialog').close()));
  const formatTime = time => {
    const hundredths = Math.max(0, Math.round((Number(time) || 0) * 100));
    return `${String(Math.floor(hundredths / 6000)).padStart(2, '0')}:${String(Math.floor(hundredths / 100) % 60).padStart(2, '0')}.${String(hundredths % 100).padStart(2, '0')}`;
  };
  const chapters = $$('[data-chapter]');
  function updatePlayback() {
    const time = video.currentTime || 0;
    scrubber.value = String(time);
    $('#video-current').textContent = formatTime(time);
    videoToggle.textContent = video.paused ? '播放' : '暂停';
    videoToggle.setAttribute('aria-label', video.paused ? '播放视频' : '暂停视频');
    const active = chapters.filter(chapter => Number(chapter.dataset.chapter) <= time + .05).at(-1);
    chapters.forEach(chapter => { chapter.classList.toggle('is-active', chapter === active); chapter.setAttribute('aria-pressed', String(chapter === active)); });
  }
  function tryPlay() {
    const attempt = video.play();
    if (attempt?.catch) attempt.catch(() => { updatePlayback(); });
  }
  let requestedTime = null;
  function seek(time, play = true) {
    const target = Math.max(0, Math.min(Number(time) || 0, Number.isFinite(video.duration) ? video.duration : 9.98));
    if (video.readyState >= 1) { video.currentTime = target; requestedTime = null; }
    else requestedTime = target;
    if (play) tryPlay();
    updatePlayback();
  }
  function openVideo(time = 0, origin) {
    const previousOrigin = origin || document.activeElement;
    if (frameDialog.open) frameDialog.close();
    openDialog(videoDialog, previousOrigin);
    $('#video-error').hidden = true;
    seek(time);
  }
  $$('[data-play-video]').forEach(button => button.addEventListener('click', () => openVideo(button.dataset.time || 0, button)));
  video.addEventListener('loadedmetadata', () => {
    scrubber.max = String(video.duration);
    $('#video-duration').textContent = formatTime(video.duration);
    if (requestedTime !== null) { video.currentTime = requestedTime; requestedTime = null; }
    updatePlayback();
  });
  ['timeupdate', 'play', 'pause', 'ended', 'seeked'].forEach(type => video.addEventListener(type, updatePlayback));
  video.addEventListener('error', () => { $('#video-error').hidden = false; });
  videoToggle.addEventListener('click', () => { if (video.paused) tryPlay(); else video.pause(); });
  scrubber.addEventListener('input', () => { video.pause(); seek(scrubber.value, false); });
  chapters.forEach(button => button.addEventListener('click', () => seek(button.dataset.chapter)));

  // 筛选后，画面浏览只在当前可见集合中前后移动。
  const cards = $$('.archive-card');
  let visibleCards = cards.slice();
  let activeCard = null;
  const filters = $$('[data-filter]');
  filters.forEach(button => button.addEventListener('click', () => {
    filters.forEach(filter => filter.setAttribute('aria-pressed', String(filter === button)));
    cards.forEach(card => { card.hidden = button.dataset.filter !== 'all' && card.dataset.category !== button.dataset.filter; });
    visibleCards = cards.filter(card => !card.hidden);
    $('#archive-count').textContent = `${String(visibleCards.length).padStart(2, '0')} / ${String(cards.length).padStart(2, '0')}`;
  }));
  function showFrame(card) {
    activeCard = card;
    $('#frame-image').src = card.dataset.image;
    $('#frame-image').alt = $('img', card).alt;
    $('#frame-title').textContent = card.dataset.title;
    $('#frame-description').textContent = card.dataset.description;
    $('#frame-time').textContent = formatTime(card.dataset.time);
    const index = visibleCards.indexOf(card);
    $('#frame-prev').disabled = index <= 0;
    $('#frame-next').disabled = index >= visibleCards.length - 1;
  }
  cards.forEach(card => card.addEventListener('click', () => { showFrame(card); openDialog(frameDialog, card); }));
  function moveFrame(direction) {
    const next = visibleCards[visibleCards.indexOf(activeCard) + direction];
    if (next) showFrame(next);
  }
  $('#frame-prev').addEventListener('click', () => moveFrame(-1));
  $('#frame-next').addEventListener('click', () => moveFrame(1));
  frameDialog.addEventListener('keydown', event => {
    if (event.key === 'ArrowLeft') { event.preventDefault(); moveFrame(-1); }
    if (event.key === 'ArrowRight') { event.preventDefault(); moveFrame(1); }
  });
  $('#frame-play').addEventListener('click', () => openVideo(Number(activeCard?.dataset.time || 0), activeCard));

  function bindTabs(selector, datasetKey, panelPrefix) {
    const tabs = $$(selector);
    function activate(tab, focus) {
      tabs.forEach(item => {
        const selected = item === tab;
        item.setAttribute('aria-selected', String(selected));
        item.tabIndex = selected ? 0 : -1;
        $(`#${panelPrefix}${item.dataset[datasetKey]}`).hidden = !selected;
      });
      if (focus) tab.focus();
    }
    tabs.forEach((tab, index) => {
      tab.addEventListener('click', () => activate(tab, false));
      tab.addEventListener('keydown', event => {
        let target;
        if (['ArrowRight', 'ArrowDown'].includes(event.key)) target = tabs[(index + 1) % tabs.length];
        if (['ArrowLeft', 'ArrowUp'].includes(event.key)) target = tabs[(index - 1 + tabs.length) % tabs.length];
        if (event.key === 'Home') target = tabs[0];
        if (event.key === 'End') target = tabs.at(-1);
        if (target) { event.preventDefault(); activate(target, true); }
      });
    });
  }
  bindTabs('[data-visual-tab]', 'visualTab', 'visual-');
  bindTabs('[data-console-tab]', 'consoleTab', 'console-');
  $('#show-grid').addEventListener('change', event => $('#symbol-board').classList.toggle('show-grid', event.target.checked));
  $('#symbol-scale').addEventListener('input', event => {
    $('#symbol-board').style.setProperty('--symbol-scale', Number(event.target.value) / 100);
    $('#symbol-scale-value').textContent = `${event.target.value}%`;
  });

  const range = $('#frequency-range');
  const readout = $('#frequency-output');
  const meter = $('#frequency-meter');
  const calibrate = $('#calibrate-button');
  const status = $('#calibration-status');
  const consolePanel = $('.console');
  let calibrationFrame = 0;
  function updateFrequency(value) {
    const amount = Math.max(0, Math.min(Number(value), 100));
    readout.textContent = amount.toFixed(2);
    meter.style.width = `${amount}%`;
    consolePanel.style.setProperty('--signal-strength', amount / 100);
  }
  function cancelCalibration() {
    cancelAnimationFrame(calibrationFrame);
    calibrationFrame = 0;
    range.disabled = false;
    calibrate.disabled = false;
    consolePanel.classList.remove('is-calibrating');
    consolePanel.removeAttribute('aria-busy');
  }
  range.addEventListener('input', () => {
    cancelCalibration();
    updateFrequency(range.value);
    calibrate.innerHTML = '开始校准 <svg aria-hidden="true"><use href="#icon-arrow"/></svg>';
    status.textContent = `目标已设定：${Number(range.value).toFixed(2)}% / READY`;
  });
  calibrate.addEventListener('click', () => {
    cancelCalibration();
    const target = Number(range.value);
    calibrate.disabled = true;
    range.disabled = true;
    calibrate.textContent = '校准中…';
    consolePanel.classList.add('is-calibrating');
    consolePanel.setAttribute('aria-busy', 'true');
    status.textContent = '正在校准 / CALIBRATING';
    const start = performance.now();
    function finish() {
      updateFrequency(target);
      cancelCalibration();
      calibrate.innerHTML = '重新校准 <svg aria-hidden="true"><use href="#icon-arrow"/></svg>';
      status.textContent = `校准完成：${target.toFixed(2)}% / COMPLETE`;
    }
    if (reducedMotion) { finish(); return; }
    const tick = now => {
      const progress = Math.min((now - start) / 1400, 1);
      updateFrequency(target * (1 - Math.pow(1 - progress, 3)));
      if (progress < 1) calibrationFrame = requestAnimationFrame(tick); else finish();
    };
    calibrationFrame = requestAnimationFrame(tick);
  });
  $('#console-reset').addEventListener('click', () => {
    cancelCalibration();
    range.value = '83.67';
    updateFrequency(83.67);
    calibrate.innerHTML = '开始校准 <svg aria-hidden="true"><use href="#icon-arrow"/></svg>';
    status.textContent = '已恢复初始读数 / READY';
  });
  const memoryMessage = $('#memory-message');
  memoryMessage.setAttribute('aria-hidden', 'true');
  $('#memory-button').addEventListener('click', () => {
    memoryMessage.classList.add('is-revealed');
    memoryMessage.removeAttribute('aria-hidden');
    $('#memory-button').textContent = '记忆已读取';
    $('#memory-button').disabled = true;
  });
  $('#memory-reset').addEventListener('click', () => {
    memoryMessage.classList.remove('is-revealed');
    memoryMessage.setAttribute('aria-hidden', 'true');
    $('#memory-button').innerHTML = '读取记忆 <svg aria-hidden="true"><use href="#icon-arrow"/></svg>';
    $('#memory-button').disabled = false;
  });

  const menuButton = $('#menu-toggle');
  const nav = $('#main-nav');
  function closeMenu() { nav.classList.remove('is-open'); menuButton.setAttribute('aria-expanded', 'false'); menuButton.setAttribute('aria-label', '打开导航'); }
  menuButton.addEventListener('click', () => {
    const open = nav.classList.toggle('is-open');
    menuButton.setAttribute('aria-expanded', String(open));
    menuButton.setAttribute('aria-label', open ? '关闭导航' : '打开导航');
  });
  const navLinks = $$('a', nav);
  navLinks.forEach(link => link.addEventListener('click', closeMenu));
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && nav.classList.contains('is-open')) { closeMenu(); menuButton.focus(); } });
  document.addEventListener('click', event => { if (!event.target.closest('.site-header')) closeMenu(); });
  // 根据视口顶部所在的章节更新导航，包含筛选改变页面高度的情况。
  let scrollFrame = 0;
  const sections = navLinks.map(link => $(link.getAttribute('href')));
  function updateActiveSection() {
    let active = sections[0];
    const threshold = Math.min(window.innerHeight * .33, 220);
    sections.forEach(section => { if (section.getBoundingClientRect().top <= threshold) active = section; });
    navLinks.forEach(link => {
      if (link.getAttribute('href') === `#${active.id}`) link.setAttribute('aria-current', 'true');
      else link.removeAttribute('aria-current');
    });
    scrollFrame = 0;
  }
  window.addEventListener('scroll', () => { if (!scrollFrame) scrollFrame = requestAnimationFrame(updateActiveSection); }, { passive: true });
  window.addEventListener('resize', () => { if (window.innerWidth > 540) closeMenu(); updateActiveSection(); });
  updateActiveSection();
  $$('[data-scroll-top]').forEach(button => button.addEventListener('click', () => window.scrollTo({ top: 0, behavior: reducedMotion ? 'instant' : 'smooth' })));
})();
