'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

const ROOT = fs.realpathSync(__dirname);
const PORT = Number(process.env.PORT || 4177);
const HOST = '127.0.0.1';
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.mp3': 'audio/mpeg',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/plain; charset=utf-8',
};

if (!Number.isInteger(PORT) || PORT < 1 || PORT > 65535) {
  console.error('PORT must be an integer between 1 and 65535.');
  process.exit(1);
}

function insideRoot(filePath) {
  const relative = path.relative(ROOT, filePath);
  return relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative));
}

function respond(res, status, message, extraHeaders = {}) {
  const body = `${message}\n`;
  res.writeHead(status, {
    'Content-Type': 'text/plain; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'X-Content-Type-Options': 'nosniff',
    ...extraHeaders,
  });
  res.end(body);
}

function parseRange(header, size) {
  const match = /^bytes=(\d*)-(\d*)$/.exec(header.trim());
  if (!match || (!match[1] && !match[2]) || size === 0) return null;
  let start;
  let end;
  if (!match[1]) {
    const suffix = Number(match[2]);
    if (!Number.isSafeInteger(suffix) || suffix <= 0) return null;
    start = Math.max(0, size - suffix);
    end = size - 1;
  } else {
    start = Number(match[1]);
    end = match[2] ? Number(match[2]) : size - 1;
    if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start >= size || end < start) return null;
    end = Math.min(end, size - 1);
  }
  return { start, end };
}

const server = http.createServer(async (req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    return respond(res, 405, 'Method not allowed', { Allow: 'GET, HEAD' });
  }

  let requestedPath;
  try {
    requestedPath = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    if (requestedPath.includes('\0')) throw new Error('Invalid path');
  } catch {
    return respond(res, 400, 'Invalid request path');
  }

  let filePath = path.resolve(ROOT, requestedPath.replace(/^[/\\]+/, ''));
  if (!insideRoot(filePath)) return respond(res, 403, 'Forbidden');

  try {
    let stat = await fs.promises.stat(filePath);
    if (stat.isDirectory()) filePath = path.join(filePath, 'index.html');
    filePath = await fs.promises.realpath(filePath);
    if (!insideRoot(filePath)) return respond(res, 403, 'Forbidden');
    stat = await fs.promises.stat(filePath);
    if (!stat.isFile()) return respond(res, 404, 'Not found');

    const headers = {
      'Content-Type': MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream',
      'Accept-Ranges': 'bytes',
      'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff',
      'Content-Length': stat.size,
    };
    let range;
    // HEAD describes the full resource; Range is only applied to GET.
    if (req.method === 'GET' && req.headers.range) {
      range = parseRange(req.headers.range, stat.size);
      if (!range) return respond(res, 416, 'Range not satisfiable', { 'Content-Range': `bytes */${stat.size}` });
      headers['Content-Range'] = `bytes ${range.start}-${range.end}/${stat.size}`;
      headers['Content-Length'] = range.end - range.start + 1;
    }
    res.writeHead(range ? 206 : 200, headers);
    if (req.method === 'HEAD' || stat.size === 0) return res.end();

    const stream = fs.createReadStream(filePath, range || {});
    stream.on('error', () => res.destroy());
    res.on('close', () => stream.destroy());
    stream.pipe(res);
  } catch (error) {
    const status = error.code === 'ENOENT' || error.code === 'ENOTDIR' ? 404 : 500;
    respond(res, status, status === 404 ? 'Not found' : 'Unable to read file');
  }
});

server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`Port ${PORT} is already in use. Set PORT to another number and try again.`);
  } else {
    console.error(error.message);
  }
  process.exitCode = 1;
});

server.listen(PORT, HOST, () => {
  const address = `http://localhost:${PORT}`;
  console.log(`Priestess UI preview: ${address}`);
  console.log('Press Ctrl+C to stop the local preview.');
  if (process.argv.includes('--open')) {
    const command = process.platform === 'win32' ? 'cmd.exe' : process.platform === 'darwin' ? 'open' : 'xdg-open';
    const args = process.platform === 'win32' ? ['/d', '/c', 'start', '', address] : [address];
    const opener = spawn(command, args, { stdio: 'ignore', windowsHide: true });
    opener.on('error', () => console.log(`Open this address in your browser: ${address}`));
    opener.unref();
  }
});
